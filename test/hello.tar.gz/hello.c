#include <stdio.h>
int main(){ printf("hello from aarch64!\n"); return 0; }
